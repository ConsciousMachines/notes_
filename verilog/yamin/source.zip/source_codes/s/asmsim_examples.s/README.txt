
Please download the newest version of AsmSim.jar from 

http://cis.k.hosei.ac.jp/~yamin/asm/

